﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Report_App.Models.Entities;

namespace Report_App.Context;

public partial class DataContext : DbContext
{
    public DataContext()
    {
    }

    public DataContext(DbContextOptions<DataContext> options)
        : base(options)
    {
    }

    public virtual DbSet<CaseStatus> CaseStatuses { get; set; }

    public virtual DbSet<Comment> Comments { get; set; }

    public virtual DbSet<Person> Persons { get; set; }

    public virtual DbSet<PersonType> PersonTypes { get; set; }

    public virtual DbSet<Report> Reports { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\hebah\\Downloads\\Report-App\\Report-App\\Report-App\\Context\\Local_DB.mdf;Integrated Security=True;Connect Timeout=30");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CaseStatus>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__CaseStat__3214EC07C21BB409");

            entity.ToTable("CaseStatus");

            entity.Property(e => e.StatusBody).HasMaxLength(50);
        });

        modelBuilder.Entity<Comment>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Comments__3214EC07C0CD98C7");

            entity.HasOne(d => d.Person).WithMany(p => p.Comments)
                .HasForeignKey(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Comments__Person__4316F928");

            entity.HasOne(d => d.Report).WithMany(p => p.Comments)
                .HasForeignKey(d => d.ReportId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Comments__Report__440B1D61");
        });

        modelBuilder.Entity<Person>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Persons__3214EC0742073249");

            entity.HasIndex(e => e.PhoneNumber, "UQ__Persons__85FB4E3875E7F43F").IsUnique();

            entity.HasIndex(e => e.Email, "UQ__Persons__A9D10534023B1A45").IsUnique();

            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FirstName).HasMaxLength(15);
            entity.Property(e => e.LastName).HasMaxLength(15);
            entity.Property(e => e.PhoneNumber).HasMaxLength(13);

            entity.HasOne(d => d.Type).WithMany(p => p.People)
                .HasForeignKey(d => d.TypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Persons__TypeId__3A81B327");
        });

        modelBuilder.Entity<PersonType>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__PersonTy__3214EC072FCF4EA1");

            entity.Property(e => e.TypeBody).HasMaxLength(8);
        });

        modelBuilder.Entity<Report>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Reports__3214EC07D4802B7A");

            entity.Property(e => e.Title).HasMaxLength(50);

            entity.HasOne(d => d.Person).WithMany(p => p.Reports)
                .HasForeignKey(d => d.PersonId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reports__PersonI__403A8C7D");

            entity.HasOne(d => d.Status).WithMany(p => p.Reports)
                .HasForeignKey(d => d.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reports__StatusI__3F466844");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
