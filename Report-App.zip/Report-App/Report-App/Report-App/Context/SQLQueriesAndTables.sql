﻿CREATE TABLE PersonTypes (
	Id int not null identity primary key,
	TypeBody nvarchar(8) not null,
)
GO

CREATE TABLE Persons (
	Id int not null identity primary key,
	FirstName nvarchar (15) not null,
	LastName nvarchar (15) not null,
	Email nvarchar (100) not null unique,
	PhoneNumber nvarchar (13) not null unique,
	TypeId int not null references PersonTypes(Id)
)
Go

CREATE TABLE CaseStatus (
	Id int not null identity primary key,
	StatusBody nvarchar(50) not null,
)
GO

CREATE TABLE Reports (
	Id int not null identity primary key,
	Dates DateTime2 not null,
	Title nvarchar(50) not null,
	Descriptions nvarchar(max) not null,
	StatusId int not null references CaseStatus(Id),
	PersonId int not null references Persons(Id),
	
)
Go

CREATE TABLE Comments (
	Id int not null identity primary key,
	Dates DateTime2 not null,
	CommentBody nvarchar(max) not null,
	PersonId int not null references Persons(Id),
	ReportId int not null references Reports(Id)
)
Go



INSERT INTO PersonTypes VALUES 
('Customer'),
('Employee')

GO

INSERT INTO CaseStatus VALUES 
('RECEIVED'),
('UNDER PROCES'),
('COMPLETED')
GO


INSERT INTO Persons VALUES
('Ali', 'Ahmad', 'aliahmad@domain.com','0767246532',1),
('Lina', 'Abraham', 'linaabraham@domain.com','0731109234',1),
('Sara', 'Adam', 'saraadam@domain.com','073497789234',1),
('Hebah', 'AliBik', 'hebahalibik@domain.com','0789109755',2),
('Yousef', 'Salah', 'yousefsalah@domain.com','0787792362',2),
('Luna', 'Omar', 'lunaomar@domain.com','0778120901',2)
GO

INSERT INTO Reports VALUES
('9-3-2023 13:30:22','Problem','The computer doesnt work',1,1)
Go


