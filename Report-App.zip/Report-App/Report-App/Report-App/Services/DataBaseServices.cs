﻿using Report_App.Context;
using Report_App.Models.Entities;
using System;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Report_App.Services
{
    internal class DataBaseServices
    {
        DataContext _context = new DataContext();
        public int CheckCustomer(Person person)
        {

            var query = (from p in _context.Persons
                         where p.Email == person.Email
                         select p.Id).SingleOrDefault();
            //Console.WriteLine(query);

            return query;
        }

        public int CheckEmployee(string mail)
        {
            var query = (from m in _context.Persons
                         where m.Email == mail
                         where m.TypeId == 2
                         select m.Id).SingleOrDefault();
            return query;
        }

        public int AddCustomer(Person person)
        {
            _context.Add(person);
            _context.SaveChanges();
            int s = CheckCustomer(person);
            return s;
        }

        public void AddReport(Report report)
        {
            _context.Add(report);
            _context.SaveChanges();
            Console.Clear();
            Console.WriteLine("Your report has been send successfully!");
        }

        public void ViewAllReports()
        {

            var reports = _context.Reports.ToList();
            Console.Clear();

            if (reports.Count > 0)
            {
                foreach (var report in reports)
                {
                    var FirstName = (from m in _context.Persons
                                     where report.PersonId == m.Id
                                     select m.FirstName).SingleOrDefault();
                    var LastName = (from x in _context.Persons
                                    where report.PersonId == x.Id
                                    select x.LastName).SingleOrDefault();
                    var status = (from z in _context.CaseStatuses
                                  where report.StatusId == z.Id
                                  select z.StatusBody).SingleOrDefault();

                    Console.WriteLine($"Report Id: {report.Id}");
                    Console.WriteLine($"Report title: {report.Title}");
                    Console.WriteLine($"Report writer full name: {FirstName} {LastName}");
                    Console.WriteLine($"Report status: {status}");
                    Console.WriteLine("===============================");
                }
            }
            else { Console.WriteLine("There is no report to view"); }
        }

        public void ViewAReports(int ID)
        {
            using (var contexts = new DataContext())
            {
                var reports = from p in contexts.Reports
                              where p.Id == ID
                              select p;
                Console.Clear();

                if (reports != null)
                {
                    foreach (var report in reports)
                    {
                        var FirstName = (from a in _context.Persons
                                         where report.PersonId == a.Id
                                         select a.FirstName).SingleOrDefault();
                        var LastName = (from b in _context.Persons
                                        where report.PersonId == b.Id
                                        select b.LastName).SingleOrDefault();
                        var status = (from c in _context.CaseStatuses
                                      where report.StatusId == c.Id
                                      select c.StatusBody).SingleOrDefault();
                        var comment = (from y in _context.Comments
                                       where report.Id == y.ReportId
                                       select y.CommentBody).SingleOrDefault();
                        Console.WriteLine($"Report Id: {report.Id}");
                        Console.WriteLine($"Date and Time: {report.Dates}");
                        Console.WriteLine($"Report title: {report.Title}");
                        Console.WriteLine($"Report details: {report.Descriptions}");
                        Console.WriteLine($"Report writer ID: {report.PersonId}");
                        Console.WriteLine($"Report writer full name: {FirstName} {LastName}");
                        Console.WriteLine($"Report status: {status}");
                        if (comment != null)
                            Console.WriteLine($"Comment to report: {comment}");
                        Console.WriteLine("===============================");
                    }
                }
                else { Console.WriteLine("There is no report to view"); }
            }
        }

        public string CurrentStatus(int id)
        {
            var query = (from m in _context.Reports
                         where m.Id == id
                         select m.StatusId).SingleOrDefault();
            var status = (from m in _context.CaseStatuses
                         where m.Id == query
                         select m.StatusBody).SingleOrDefault();
            return status;

        }
        public void ChangeStatus(int ID, int s)
        {
            var status = _context.Reports.First(a => a.Id == ID);
            status.StatusId = s;
            _context.SaveChanges();

        }

        public void AddComment(Comment comment)
        {
            _context.Comments.Add(comment);
            _context.SaveChanges();
            Console.Clear();
            Console.WriteLine("The comment has been added successfully!");
        }
    }
}

