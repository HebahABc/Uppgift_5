﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Report_App.Models
{
    internal class ReportModel
    {
        public int Id { get; set; }

        public DateTime Dates { get; set; }

        public string Title { get; set; } = null!;

        public string Descriptions { get; set; } = null!;
    }
}
