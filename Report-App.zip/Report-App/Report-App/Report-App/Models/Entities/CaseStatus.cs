﻿using System;
using System.Collections.Generic;

namespace Report_App.Models.Entities;

public partial class CaseStatus
{
    public int Id { get; set; }

    public string StatusBody { get; set; } = null!;

    public virtual ICollection<Report> Reports { get; } = new List<Report>();
}
