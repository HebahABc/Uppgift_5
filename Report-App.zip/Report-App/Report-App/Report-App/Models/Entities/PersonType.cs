﻿using System;
using System.Collections.Generic;

namespace Report_App.Models.Entities;

public partial class PersonType
{
    public int Id { get; set; }

    public string TypeBody { get; set; } = null!;

    public virtual ICollection<Person> People { get; } = new List<Person>();
}
