﻿using System;
using System.Collections.Generic;

namespace Report_App.Models.Entities;

public partial class Comment
{
    public int Id { get; set; }

    public DateTime Dates { get; set; }

    public string CommentBody { get; set; } = null!;

    public int PersonId { get; set; }

    public int ReportId { get; set; }

    public virtual Person Person { get; set; } = null!;

    public virtual Report Report { get; set; } = null!;
}
