﻿using System;
using System.Collections.Generic;

namespace Report_App.Models.Entities;

public partial class Person
{
    public int Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public int TypeId { get; set; }

    public virtual ICollection<Comment> Comments { get; } = new List<Comment>();

    public virtual ICollection<Report> Reports { get; } = new List<Report>();

    public virtual PersonType Type { get; set; } = null!;
}
