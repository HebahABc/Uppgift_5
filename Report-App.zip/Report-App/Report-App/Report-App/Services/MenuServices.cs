﻿
using Microsoft.EntityFrameworkCore;
using Report_App.Context;
using Report_App.Models;
using Report_App.Models.Entities;

namespace Report_App.Services
{
    internal class MenuServices
    {
        public string Menu()
        {
            Console.WriteLine("Please choose one of the following options:");
            Console.WriteLine("For customers press 1");
            Console.WriteLine("For employees press 2");
            Console.WriteLine("To exit press q");
            string s = Console.ReadLine().Trim() ?? "";

            while (s == "")
            {
                Console.WriteLine("Please Choose one of the above options:");
                s = Console.ReadLine().Trim() ?? "";
            }
            return s;
        }

        public string CustomerMenu()
        {
            Console.WriteLine("Please Choose one of the folowing options:");
            Console.WriteLine("To apply a report press 1");
            Console.WriteLine("To back to main menu press b");
            string s = Console.ReadLine().Trim() ?? "";
            if (s == null)
            {
                Console.WriteLine("You don't choos any option:");
                CustomerMenu();
            }

            return s;
        }

        public string StatusMenu(string x)
        {
            Console.Clear();
            Console.WriteLine($"The current status: {x}");
            Console.WriteLine("Choose the new status:");
            Console.WriteLine("1. RECIVED");
            Console.WriteLine("2. UNDER PROCESSING");
            Console.WriteLine("3. Completed");
            Console.WriteLine("0. To go back");
            return Console.ReadLine().Trim() ?? "";

        }

        public Person AddCustomerForm(int x)
        {
            Person person = new Person();
            Console.Write("Please Enter Your First Name:");
            person.FirstName = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter Your Last Name:");
            person.LastName = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter Your Email Address:");
            person.Email = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter Your Phone Number:");
            person.PhoneNumber = Console.ReadLine().Trim() ?? "";
            person.TypeId = x;

            return person;
        }

        public Report WriteReport(int x)
        {
            Report report = new Report();
            report.PersonId = x;
            report.StatusId = 1;
            report.Dates = DateTime.Now;
            Console.Write("Enter the title of your report:");
            report.Title = Console.ReadLine().Trim() ?? "";
            Console.Write("Discribe your issue:");
            report.Descriptions = Console.ReadLine().Trim() ?? "";

            return report;
        }


        public string EmployeeMenu()
        {
            Console.WriteLine("Please Choose one of the folowing options:");
            Console.WriteLine("1. View all reports");
            Console.WriteLine("2. View a report in details");
            Console.WriteLine("3. Change the status of a report");
            Console.WriteLine("4. Write a comment to a report");
            Console.WriteLine("Press 'b' to back to the main menu");
            string s = Console.ReadLine().Trim() ?? "";
            if (s == null)
            {
                Console.WriteLine("You don't choos any option:");
                EmployeeMenu();
            }

            return s;
        }

        public Comment WriteComment(int x)
        {
            Comment comment = new Comment();
            comment.ReportId = x;
            DataContext context = new DataContext();
            var person = (from m in context.Reports
                         where m.Id == x
                         select m.PersonId).SingleOrDefault();
            Console.WriteLine("Enter your comment:");
            comment.CommentBody = Console.ReadLine().Trim() ?? "";
            comment.Dates = DateTime.Now;
            comment.PersonId = person;
            return comment;
        }
    }

    
}
