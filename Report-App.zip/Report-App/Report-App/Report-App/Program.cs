﻿using Report_App.Models;
using Report_App.Models.Entities;
using Report_App.Services;

MenuServices menu =  new MenuServices();
DataBaseServices DBaseServices = new DataBaseServices();

string choice;
string CustomerMenuCoice;
do
{
    choice = menu.Menu();

    switch (choice)
    {
        case "1":
            {
                Console.Clear();
                Console.WriteLine("You entered as a customer");
                CustomerMenuCoice = menu.CustomerMenu ();
                if (CustomerMenuCoice == "1")
                {
                    Console.Clear ();
                    var person = menu.AddCustomerForm(int.Parse(CustomerMenuCoice));
                    int check = DBaseServices.CheckCustomer(person);
                    if (check == 0)
                    {
                        int x = DBaseServices.AddCustomer(person);
                        var report = menu.WriteReport(x);
                        DBaseServices.AddReport(report);
                    }
                    else
                    {
                        Console.WriteLine("Your data are already exist!");
                        var report = menu.WriteReport(check);
                        DBaseServices.AddReport(report);
                    }

                }
                else if (CustomerMenuCoice == "b")
                {
                    Console.Clear ();
                    menu.Menu ();
                }
                break;
            }

        case "2":
            {
                
                Console.Clear();
                Console.WriteLine("You enter as an employee");
                Console.WriteLine("Please enter your email");
                var mail = Console.ReadLine().Trim() ?? "";
                int isEmployee = DBaseServices.CheckEmployee(mail);
                if (isEmployee == 0)
                {
                    Console.Clear();
                    Console.WriteLine("You aren't an employee, so you can't enter here!");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                }
                else
                {
                    string employee = menu.EmployeeMenu();
                    switch (employee)
                    {
                        case "1":
                            {
                                DBaseServices.ViewAllReports();
                                break;
                            }
                        case "2":
                            {
                                Console.Clear() ;
                                Console.WriteLine("Enter the Id of the report");
                                string ID = Console.ReadLine().Trim() ?? "";
                                DBaseServices.ViewAReports(int.Parse(ID));
                                break; 
                            }
                        case "3": 
                            { 
                                Console.Clear() ;
                                Console.WriteLine("Enter the Id of the report");
                                string ID = Console.ReadLine().Trim() ?? "";
                                string status = DBaseServices.CurrentStatus(int.Parse(ID));
                                string s = menu.StatusMenu(status);
                                DBaseServices.ChangeStatus(int.Parse(ID), int.Parse(s));
                                Console.Clear();
                                Console.WriteLine("The status has been updated successfully!");
                                break; 
                            }
                        case "4": 
                            {
                                Console.Clear();
                                Console.WriteLine("Enter the Id of the report");
                                string ID = Console.ReadLine().Trim() ?? "";
                                var comment = menu.WriteComment(int.Parse(ID));
                                DBaseServices.AddComment(comment);
                                break; 
                            }
                        case "b": { break; }
                        default: 
                            {
                                Console.WriteLine("You have to choose from 1 to 4 or b to exit");
                                break; 
                            }
                    }
                };
                
                break;
            }
        case "q":
            {
                break;
            }


        default:
            {
                Console.Clear();
                Console.WriteLine("\n You have to press 1 or 2 only");
                break;
            }
    }
}

while (choice != "q");