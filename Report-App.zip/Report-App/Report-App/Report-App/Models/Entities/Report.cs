﻿using System;
using System.Collections.Generic;

namespace Report_App.Models.Entities;

public partial class Report
{
    public int Id { get; set; }

    public DateTime Dates { get; set; }

    public string Title { get; set; } = null!;

    public string Descriptions { get; set; } = null!;

    public int StatusId { get; set; }

    public int PersonId { get; set; }

    public virtual ICollection<Comment> Comments { get; } = new List<Comment>();

    public virtual Person Person { get; set; } = null!;

    public virtual CaseStatus Status { get; set; } = null!;
}
